/*
# Smart Study Companion - Initial Database Schema

## 1. Overview
This migration creates the complete database structure for the Smart Study Companion app,
including user profiles, study sessions, documents, flashcards, quizzes, achievements, and more.

## 2. New Tables

### profiles
- `id` (uuid, primary key, references auth.users)
- `email` (text, unique)
- `username` (text, unique)
- `avatar_url` (text, nullable)
- `role` (user_role enum: 'user', 'admin')
- `xp_points` (integer, default: 0)
- `level` (integer, default: 1)
- `streak_days` (integer, default: 0)
- `last_study_date` (date, nullable)
- `created_at` (timestamptz, default: now())
- `updated_at` (timestamptz, default: now())

### subjects
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `name` (text, not null)
- `color` (text, default: '#3B82F6')
- `icon` (text, nullable)
- `created_at` (timestamptz, default: now())

### study_sessions
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `subject_id` (uuid, references subjects)
- `topic` (text, not null)
- `duration_minutes` (integer, not null)
- `difficulty` (text: 'easy', 'medium', 'hard')
- `importance` (text: 'low', 'medium', 'high')
- `notes` (text, nullable)
- `date` (date, not null)
- `created_at` (timestamptz, default: now())

### documents
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `subject_id` (uuid, references subjects, nullable)
- `title` (text, not null)
- `file_url` (text, not null)
- `file_type` (text, not null)
- `processed` (boolean, default: false)
- `extracted_text` (text, nullable)
- `topics` (jsonb, nullable)
- `created_at` (timestamptz, default: now())

### flashcards
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `subject_id` (uuid, references subjects, nullable)
- `document_id` (uuid, references documents, nullable)
- `question` (text, not null)
- `answer` (text, not null)
- `difficulty` (text: 'easy', 'medium', 'hard')
- `next_review_date` (date, not null)
- `review_count` (integer, default: 0)
- `confidence_level` (integer, default: 0, range: 0-5)
- `created_at` (timestamptz, default: now())

### quizzes
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `subject_id` (uuid, references subjects, nullable)
- `document_id` (uuid, references documents, nullable)
- `title` (text, not null)
- `questions` (jsonb, not null)
- `total_questions` (integer, not null)
- `difficulty` (text: 'easy', 'medium', 'hard')
- `created_at` (timestamptz, default: now())

### quiz_attempts
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `quiz_id` (uuid, references quizzes)
- `score` (integer, not null)
- `total_questions` (integer, not null)
- `answers` (jsonb, not null)
- `time_taken_seconds` (integer, not null)
- `completed_at` (timestamptz, default: now())

### study_plans
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `title` (text, not null)
- `description` (text, nullable)
- `start_date` (date, not null)
- `end_date` (date, not null)
- `tasks` (jsonb, not null)
- `created_at` (timestamptz, default: now())

### achievements
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `achievement_type` (text, not null)
- `title` (text, not null)
- `description` (text, not null)
- `icon` (text, not null)
- `xp_reward` (integer, not null)
- `unlocked_at` (timestamptz, default: now())

### notifications
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `title` (text, not null)
- `message` (text, not null)
- `type` (text: 'reminder', 'achievement', 'tip')
- `read` (boolean, default: false)
- `created_at` (timestamptz, default: now())

## 3. Security
- Enable RLS on all tables
- Create admin helper function
- Users can only access their own data
- Admins have full access to all data
- First registered user becomes admin automatically

## 4. Functions & Triggers
- Auto-update updated_at timestamp
- Handle new user registration and profile creation
- Calculate user level based on XP points
- Update streak tracking
*/

-- Create ENUM types
CREATE TYPE user_role AS ENUM ('user', 'admin');
CREATE TYPE difficulty_level AS ENUM ('easy', 'medium', 'hard');
CREATE TYPE importance_level AS ENUM ('low', 'medium', 'high');
CREATE TYPE notification_type AS ENUM ('reminder', 'achievement', 'tip');

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE,
  username text UNIQUE,
  avatar_url text,
  role user_role DEFAULT 'user'::user_role NOT NULL,
  xp_points integer DEFAULT 0 NOT NULL,
  level integer DEFAULT 1 NOT NULL,
  streak_days integer DEFAULT 0 NOT NULL,
  last_study_date date,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create subjects table
CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  color text DEFAULT '#3B82F6' NOT NULL,
  icon text,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create study_sessions table
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  topic text NOT NULL,
  duration_minutes integer NOT NULL,
  difficulty difficulty_level DEFAULT 'medium'::difficulty_level NOT NULL,
  importance importance_level DEFAULT 'medium'::importance_level NOT NULL,
  notes text,
  date date NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  title text NOT NULL,
  file_url text NOT NULL,
  file_type text NOT NULL,
  processed boolean DEFAULT false NOT NULL,
  extracted_text text,
  topics jsonb,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create flashcards table
CREATE TABLE IF NOT EXISTS flashcards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  document_id uuid REFERENCES documents(id) ON DELETE SET NULL,
  question text NOT NULL,
  answer text NOT NULL,
  difficulty difficulty_level DEFAULT 'medium'::difficulty_level NOT NULL,
  next_review_date date NOT NULL,
  review_count integer DEFAULT 0 NOT NULL,
  confidence_level integer DEFAULT 0 NOT NULL CHECK (confidence_level >= 0 AND confidence_level <= 5),
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create quizzes table
CREATE TABLE IF NOT EXISTS quizzes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  document_id uuid REFERENCES documents(id) ON DELETE SET NULL,
  title text NOT NULL,
  questions jsonb NOT NULL,
  total_questions integer NOT NULL,
  difficulty difficulty_level DEFAULT 'medium'::difficulty_level NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create quiz_attempts table
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  quiz_id uuid REFERENCES quizzes(id) ON DELETE CASCADE NOT NULL,
  score integer NOT NULL,
  total_questions integer NOT NULL,
  answers jsonb NOT NULL,
  time_taken_seconds integer NOT NULL,
  completed_at timestamptz DEFAULT now() NOT NULL
);

-- Create study_plans table
CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  start_date date NOT NULL,
  end_date date NOT NULL,
  tasks jsonb NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  achievement_type text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  xp_reward integer NOT NULL,
  unlocked_at timestamptz DEFAULT now() NOT NULL
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  type notification_type DEFAULT 'reminder'::notification_type NOT NULL,
  read boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE flashcards ENABLE ROW LEVEL SECURITY;
ALTER TABLE quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create admin helper function
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Create function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  IF OLD IS DISTINCT FROM NULL AND OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL THEN
    SELECT COUNT(*) INTO user_count FROM profiles;
    
    INSERT INTO profiles (id, email, username, role)
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
      CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
    );
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger for new user registration
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- RLS Policies for profiles
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id) 
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- RLS Policies for subjects
CREATE POLICY "Admins have full access to subjects" ON subjects
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own subjects" ON subjects
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for study_sessions
CREATE POLICY "Admins have full access to study_sessions" ON study_sessions
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own study_sessions" ON study_sessions
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for documents
CREATE POLICY "Admins have full access to documents" ON documents
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own documents" ON documents
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for flashcards
CREATE POLICY "Admins have full access to flashcards" ON flashcards
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own flashcards" ON flashcards
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for quizzes
CREATE POLICY "Admins have full access to quizzes" ON quizzes
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own quizzes" ON quizzes
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for quiz_attempts
CREATE POLICY "Admins have full access to quiz_attempts" ON quiz_attempts
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own quiz_attempts" ON quiz_attempts
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for study_plans
CREATE POLICY "Admins have full access to study_plans" ON study_plans
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own study_plans" ON study_plans
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for achievements
CREATE POLICY "Admins have full access to achievements" ON achievements
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own achievements" ON achievements
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for notifications
CREATE POLICY "Admins have full access to notifications" ON notifications
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own notifications" ON notifications
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('app-7la5aw4xicch-documents', 'app-7la5aw4xicch-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for documents bucket
CREATE POLICY "Authenticated users can upload documents"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'app-7la5aw4xicch-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view own documents"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'app-7la5aw4xicch-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own documents"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'app-7la5aw4xicch-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Admins have full access to documents storage"
ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'app-7la5aw4xicch-documents' AND is_admin(auth.uid()));
