import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { studySessionsApi, achievementsApi } from '@/db/api';
import { Brain, BookOpen, Trophy, TrendingUp, Clock, Target, Zap, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { StudySessionWithSubject, Achievement } from '@/types/types';

export default function Dashboard() {
  const { profile } = useAuth();
  const [sessions, setSessions] = useState<StudySessionWithSubject[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      loadData();
    }
  }, [profile]);

  const loadData = async () => {
    if (!profile) return;
    
    try {
      const [sessionsData, achievementsData] = await Promise.all([
        studySessionsApi.getStudySessions(profile.id, 10),
        achievementsApi.getAchievements(profile.id)
      ]);
      
      setSessions(sessionsData);
      setAchievements(achievementsData);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalHours = sessions.reduce((sum, s) => sum + s.duration_minutes, 0) / 60;
  const todaySessions = sessions.filter(s => s.date === new Date().toISOString().split('T')[0]);
  const todayHours = todaySessions.reduce((sum, s) => sum + s.duration_minutes, 0) / 60;

  const levelProgress = ((profile?.xp_points || 0) % 1000) / 10;
  const nextLevelXP = (profile?.level || 1) * 1000;

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold mb-2">
            Welcome back, <span className="gradient-text">{profile?.username || 'Student'}</span>! 👋
          </h1>
          <p className="text-muted-foreground text-lg">
            Ready to continue your learning journey?
          </p>
        </div>
        <div className="flex gap-3">
          <Link to="/study">
            <Button size="lg" className="gap-2">
              <Clock className="w-5 h-5" />
              Start Studying
            </Button>
          </Link>
          <Link to="/ai-analysis">
            <Button size="lg" variant="outline" className="gap-2">
              <Brain className="w-5 h-5" />
              AI Analysis
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Level</CardTitle>
            <Trophy className="w-5 h-5 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-accent">{profile?.level || 1}</div>
            <Progress value={levelProgress} className="mt-3 h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              {profile?.xp_points || 0} / {nextLevelXP} XP
            </p>
          </CardContent>
        </Card>

        <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Streak</CardTitle>
            <Zap className="w-5 h-5 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-warning">{profile?.streak_days || 0}</div>
            <p className="text-xs text-muted-foreground mt-2">days in a row 🔥</p>
          </CardContent>
        </Card>

        <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Today</CardTitle>
            <Calendar className="w-5 h-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{todayHours.toFixed(1)}h</div>
            <p className="text-xs text-muted-foreground mt-2">{todaySessions.length} sessions</p>
          </CardContent>
        </Card>

        <Card className="border-primary/20 shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Hours</CardTitle>
            <Clock className="w-5 h-5 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-secondary">{totalHours.toFixed(1)}h</div>
            <p className="text-xs text-muted-foreground mt-2">{sessions.length} sessions</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" />
              Recent Study Sessions
            </CardTitle>
            <CardDescription>Your latest study activities</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">Loading...</div>
            ) : sessions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">No study sessions yet</p>
                <Link to="/study">
                  <Button>Start Your First Session</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {sessions.slice(0, 5).map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex-1">
                      <p className="font-medium">{session.topic}</p>
                      <p className="text-sm text-muted-foreground">
                        {session.subject?.name || 'No subject'} • {session.date}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-primary">{session.duration_minutes}min</p>
                      <p className="text-xs text-muted-foreground capitalize">{session.difficulty}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-accent" />
              Recent Achievements
            </CardTitle>
            <CardDescription>Your latest unlocked achievements</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">Loading...</div>
            ) : achievements.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">No achievements yet</p>
                <p className="text-sm text-muted-foreground">
                  Keep studying to unlock your first achievement!
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {achievements.slice(0, 5).map((achievement) => (
                  <div
                    key={achievement.id}
                    className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="text-3xl">{achievement.icon}</div>
                    <div className="flex-1">
                      <p className="font-medium">{achievement.title}</p>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                    </div>
                    <div className="text-accent font-semibold">+{achievement.xp_reward} XP</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <Link to="/analytics">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Analytics
              </CardTitle>
              <CardDescription>View detailed performance insights</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link to="/flashcards">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-secondary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-secondary" />
                Flashcards
              </CardTitle>
              <CardDescription>Review with spaced repetition</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link to="/study-planner">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-accent/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-accent" />
                Study Planner
              </CardTitle>
              <CardDescription>Plan your study schedule</CardDescription>
            </CardHeader>
          </Card>
        </Link>
      </div>
    </div>
  );
}
