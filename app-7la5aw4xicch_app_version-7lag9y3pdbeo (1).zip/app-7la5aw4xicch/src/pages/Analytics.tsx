import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';

export default function Analytics() {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">
          <span className="gradient-text">Analytics</span>
        </h1>
        <p className="text-muted-foreground text-lg">Track your study performance and progress</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Coming Soon
          </CardTitle>
          <CardDescription>Detailed analytics and insights will be available here</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            This feature is under development. You'll soon be able to view detailed analytics about your study habits, performance trends, and personalized recommendations.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
