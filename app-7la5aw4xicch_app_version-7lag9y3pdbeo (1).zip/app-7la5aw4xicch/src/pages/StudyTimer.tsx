import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Play, Pause, Square, Clock } from 'lucide-react';
import { studySessionsApi, subjectsApi } from '@/db/api';
import type { Subject } from '@/types/types';

export default function StudyTimer() {
  const { profile } = useAuth();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [topic, setTopic] = useState('');
  const [subjectId, setSubjectId] = useState('');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [importance, setImportance] = useState<'low' | 'medium' | 'high'>('medium');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (profile) {
      subjectsApi.getSubjects(profile.id).then(setSubjects);
    }
  }, [profile]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning) {
      interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const formatTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    if (!topic.trim()) {
      toast.error('Please enter a topic');
      return;
    }
    setIsRunning(true);
    toast.success('Study session started!');
  };

  const handlePause = () => {
    setIsRunning(false);
    toast.info('Study session paused');
  };

  const handleStop = async () => {
    if (!profile || seconds < 60) {
      toast.error('Session must be at least 1 minute long');
      return;
    }

    setIsRunning(false);
    
    try {
      await studySessionsApi.createStudySession({
        user_id: profile.id,
        subject_id: subjectId || null,
        topic: topic.trim(),
        duration_minutes: Math.floor(seconds / 60),
        difficulty,
        importance,
        notes: notes.trim() || null,
        date: new Date().toISOString().split('T')[0]
      });

      toast.success(`Study session saved! ${Math.floor(seconds / 60)} minutes recorded.`);
      
      setSeconds(0);
      setTopic('');
      setNotes('');
    } catch (error) {
      console.error('Error saving session:', error);
      toast.error('Failed to save study session');
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">
          <span className="gradient-text">Study Timer</span>
        </h1>
        <p className="text-muted-foreground text-lg">Track your study sessions and build your streak</p>
      </div>

      <div className="grid gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Timer
            </CardTitle>
            <CardDescription>Start tracking your study time</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center py-8">
              <div className="text-7xl font-bold gradient-text mb-6">
                {formatTime(seconds)}
              </div>
              <div className="flex justify-center gap-4">
                {!isRunning ? (
                  <Button size="lg" onClick={handleStart} className="gap-2">
                    <Play className="w-5 h-5" />
                    Start
                  </Button>
                ) : (
                  <Button size="lg" onClick={handlePause} variant="outline" className="gap-2">
                    <Pause className="w-5 h-5" />
                    Pause
                  </Button>
                )}
                <Button size="lg" onClick={handleStop} variant="destructive" className="gap-2" disabled={seconds === 0}>
                  <Square className="w-5 h-5" />
                  Stop & Save
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="topic">Topic *</Label>
                <Input
                  id="topic"
                  placeholder="What are you studying?"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  disabled={isRunning}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Select value={subjectId} onValueChange={setSubjectId} disabled={isRunning}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No subject</SelectItem>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select value={difficulty} onValueChange={(v) => setDifficulty(v as typeof difficulty)} disabled={isRunning}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="importance">Importance</Label>
                  <Select value={importance} onValueChange={(v) => setImportance(v as typeof importance)} disabled={isRunning}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Add any notes about this study session..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  disabled={isRunning}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
