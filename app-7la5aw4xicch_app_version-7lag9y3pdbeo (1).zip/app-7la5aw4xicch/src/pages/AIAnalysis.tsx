import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Brain, Upload, Loader2, FileText, Sparkles } from 'lucide-react';
import { aiService } from '@/services/aiService';
import { documentsApi } from '@/db/api';

export default function AIAnalysis() {
  const { profile } = useAuth();
  const [subject, setSubject] = useState('');
  const [topics, setTopics] = useState('');
  const [analysisType, setAnalysisType] = useState<'mcqs' | 'important_topics' | 'summary' | 'revision'>('summary');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!profile) return;
    
    if (!subject.trim()) {
      toast.error('Please enter a subject');
      return;
    }

    if (!file) {
      toast.error('Please upload a document');
      return;
    }

    setLoading(true);
    setResult('');

    try {
      let extractedText = '';
      
      if (file.type.startsWith('image/')) {
        extractedText = await aiService.extractTextFromImage(file);
      } else {
        const reader = new FileReader();
        extractedText = await new Promise((resolve, reject) => {
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.onerror = reject;
          reader.readAsText(file);
        });
      }

      const fileUrl = await documentsApi.uploadFile(profile.id, file);
      await documentsApi.createDocument({
        user_id: profile.id,
        subject_id: null,
        title: file.name,
        file_url: fileUrl,
        file_type: file.type,
        processed: true,
        extracted_text: extractedText,
        topics: null
      });

      const analysis = await aiService.analyzeDocument(extractedText, analysisType);
      setResult(analysis);
      toast.success('Analysis complete!');
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze document');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">
          <span className="gradient-text">AI Study Analysis</span>
        </h1>
        <p className="text-muted-foreground text-lg">
          Upload your notes and get AI-powered insights
        </p>
      </div>

      <div className="grid xl:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" />
              Upload & Configure
            </CardTitle>
            <CardDescription>Provide your study materials for analysis</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="subject">Subject *</Label>
              <Input
                id="subject"
                placeholder="e.g., Mathematics, Physics, History"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="topics">Topics Covered</Label>
              <Textarea
                id="topics"
                placeholder="List the topics you want to focus on..."
                value={topics}
                onChange={(e) => setTopics(e.target.value)}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="analysisType">Analysis Type</Label>
              <Select value={analysisType} onValueChange={(v) => setAnalysisType(v as typeof analysisType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="summary">Summary</SelectItem>
                  <SelectItem value="important_topics">Important Topics</SelectItem>
                  <SelectItem value="mcqs">Generate MCQs</SelectItem>
                  <SelectItem value="revision">Revision Notes</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="file">Upload Document *</Label>
              <Input
                id="file"
                type="file"
                accept=".pdf,.txt,.doc,.docx,image/*"
                onChange={handleFileChange}
              />
              {file && (
                <p className="text-sm text-muted-foreground">
                  Selected: {file.name}
                </p>
              )}
            </div>

            <Button onClick={handleAnalyze} disabled={loading} className="w-full gap-2">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4" />
                  Analyze with AI
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-accent" />
              Analysis Results
            </CardTitle>
            <CardDescription>AI-generated insights from your document</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex flex-col items-center justify-center py-12 space-y-4">
                <Loader2 className="w-12 h-12 animate-spin text-primary" />
                <p className="text-muted-foreground">Analyzing your document...</p>
              </div>
            ) : result ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <div className="whitespace-pre-wrap bg-muted/50 p-4 rounded-lg">
                  {result}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 space-y-4 text-center">
                <FileText className="w-16 h-16 text-muted-foreground/50" />
                <p className="text-muted-foreground">
                  Upload a document and click "Analyze with AI" to see results here
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
