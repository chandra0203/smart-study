import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from 'lucide-react';

export default function StudyPlanner() {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">
          <span className="gradient-text">Study Planner</span>
        </h1>
        <p className="text-muted-foreground text-lg">Plan and organize your study schedule</p>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-accent" />
            Coming Soon
          </CardTitle>
          <CardDescription>Study planning tools will be available here</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            This feature is under development. You'll soon be able to create study plans, set goals, and get AI-generated study schedules.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
