import type { QuizQuestion } from '@/types/types';

const APP_ID = import.meta.env.VITE_APP_ID;
const API_URL = 'https://api-integrations.appmedo.com';

interface GeminiMessage {
  role: 'user' | 'model';
  parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }>;
}

export const aiService = {
  async analyzeDocument(text: string, analysisType: string): Promise<string> {
    const prompts: Record<string, string> = {
      summary: `Please provide a concise summary of the following text:\n\n${text}`,
      important_topics: `Extract and list the most important topics and key points from the following text:\n\n${text}`,
      revision: `Create comprehensive revision notes from the following text, highlighting key concepts, formulas, and definitions:\n\n${text}`,
      weakness_check: `Analyze the following text and identify potential areas that students might find challenging or confusing:\n\n${text}`
    };

    const prompt = prompts[analysisType] || prompts.summary;
    
    try {
      const response = await fetch(`${API_URL}/${APP_ID}/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }]
            }
          ]
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  fullText += text;
                }
              } catch (e) {
                console.error('Error parsing SSE data:', e);
              }
            }
          }
        }
      }

      return fullText;
    } catch (error) {
      console.error('AI analysis error:', error);
      throw error;
    }
  },

  async generateMCQs(text: string, count = 5): Promise<QuizQuestion[]> {
    const prompt = `Generate ${count} multiple choice questions (MCQs) from the following text. 
    Format your response as a JSON array with this structure:
    [
      {
        "question": "Question text here",
        "options": ["Option A", "Option B", "Option C", "Option D"],
        "correct_answer": 0,
        "explanation": "Explanation here"
      }
    ]
    
    Text:\n${text}`;

    try {
      const response = await fetch(`${API_URL}/${APP_ID}/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }]
            }
          ]
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  fullText += text;
                }
              } catch (e) {
                console.error('Error parsing SSE data:', e);
              }
            }
          }
        }
      }

      const jsonMatch = fullText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      return [];
    } catch (error) {
      console.error('MCQ generation error:', error);
      throw error;
    }
  },

  async extractTextFromImage(imageFile: File): Promise<string> {
    try {
      const formData = new FormData();
      formData.append('file', imageFile);
      formData.append('language', 'eng');
      formData.append('isOverlayRequired', 'false');

      const response = await fetch(`${API_URL}/${APP_ID}/api-Xa6JxbyEgZea/parse/image`, {
        method: 'POST',
        headers: {
          'apikey': 'K87649693488957'
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error(`OCR request failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.OCRExitCode === '1' && data.ParsedResults?.[0]?.ParsedText) {
        return data.ParsedResults[0].ParsedText;
      }
      
      throw new Error('OCR processing failed');
    } catch (error) {
      console.error('OCR error:', error);
      throw error;
    }
  },

  async textToSpeech(text: string): Promise<Blob> {
    try {
      const response = await fetch(`${API_URL}/${APP_ID}/api-wL1znZBlexBY/v1/audio/speech`, {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer aoampOdNvwF3csAVKJNXX0h0KlQ2bDJU',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          input: text,
          voice: 'heart',
          response_format: 'mp3'
        })
      });

      if (!response.ok) {
        throw new Error(`TTS request failed: ${response.statusText}`);
      }

      return await response.blob();
    } catch (error) {
      console.error('TTS error:', error);
      throw error;
    }
  },

  async chatWithAI(messages: GeminiMessage[]): Promise<string> {
    try {
      const response = await fetch(`${API_URL}/${APP_ID}/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': APP_ID
        },
        body: JSON.stringify({
          contents: messages
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  fullText += text;
                }
              } catch (e) {
                console.error('Error parsing SSE data:', e);
              }
            }
          }
        }
      }

      return fullText;
    } catch (error) {
      console.error('Chat error:', error);
      throw error;
    }
  }
};
