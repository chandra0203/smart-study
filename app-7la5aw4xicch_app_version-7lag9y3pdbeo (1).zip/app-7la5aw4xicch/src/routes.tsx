import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Signup from './pages/Signup';
import StudyTimer from './pages/StudyTimer';
import AIAnalysis from './pages/AIAnalysis';
import Analytics from './pages/Analytics';
import Flashcards from './pages/Flashcards';
import StudyPlanner from './pages/StudyPlanner';
import Profile from './pages/Profile';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <Dashboard />,
    visible: true
  },
  {
    name: 'Study Timer',
    path: '/study',
    element: <StudyTimer />,
    visible: true
  },
  {
    name: 'AI Analysis',
    path: '/ai-analysis',
    element: <AIAnalysis />,
    visible: true
  },
  {
    name: 'Analytics',
    path: '/analytics',
    element: <Analytics />,
    visible: true
  },
  {
    name: 'Flashcards',
    path: '/flashcards',
    element: <Flashcards />,
    visible: true
  },
  {
    name: 'Study Planner',
    path: '/study-planner',
    element: <StudyPlanner />,
    visible: true
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <Profile />,
    visible: false
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false
  },
  {
    name: 'Signup',
    path: '/signup',
    element: <Signup />,
    visible: false
  }
];

export default routes;