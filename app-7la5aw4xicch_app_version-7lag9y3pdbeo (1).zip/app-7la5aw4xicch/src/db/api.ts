import { supabase } from './supabase';
import type {
  Profile,
  Subject,
  StudySession,
  Document,
  Flashcard,
  Quiz,
  QuizAttempt,
  StudyPlan,
  Achievement,
  Notification,
  StudySessionWithSubject
} from '@/types/types';

export const profilesApi = {
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  }
};

export const subjectsApi = {
  async getSubjects(userId: string): Promise<Subject[]> {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createSubject(subject: Omit<Subject, 'id' | 'created_at'>): Promise<Subject | null> {
    const { data, error } = await supabase
      .from('subjects')
      .insert(subject)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateSubject(id: string, updates: Partial<Subject>): Promise<Subject | null> {
    const { data, error } = await supabase
      .from('subjects')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async deleteSubject(id: string): Promise<void> {
    const { error } = await supabase
      .from('subjects')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};

export const studySessionsApi = {
  async getStudySessions(userId: string, limit = 100): Promise<StudySessionWithSubject[]> {
    const { data, error } = await supabase
      .from('study_sessions')
      .select('*, subject:subjects(*)')
      .eq('user_id', userId)
      .order('date', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createStudySession(session: Omit<StudySession, 'id' | 'created_at'>): Promise<StudySession | null> {
    const { data, error } = await supabase
      .from('study_sessions')
      .insert(session)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getSessionsByDateRange(userId: string, startDate: string, endDate: string): Promise<StudySessionWithSubject[]> {
    const { data, error } = await supabase
      .from('study_sessions')
      .select('*, subject:subjects(*)')
      .eq('user_id', userId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  }
};

export const documentsApi = {
  async getDocuments(userId: string): Promise<Document[]> {
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createDocument(document: Omit<Document, 'id' | 'created_at'>): Promise<Document | null> {
    const { data, error } = await supabase
      .from('documents')
      .insert(document)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateDocument(id: string, updates: Partial<Document>): Promise<Document | null> {
    const { data, error } = await supabase
      .from('documents')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async deleteDocument(id: string): Promise<void> {
    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  async uploadFile(userId: string, file: File): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Date.now()}.${fileExt}`;
    
    const { error } = await supabase.storage
      .from('app-7la5aw4xicch-documents')
      .upload(fileName, file);
    
    if (error) throw error;
    
    const { data: { publicUrl } } = supabase.storage
      .from('app-7la5aw4xicch-documents')
      .getPublicUrl(fileName);
    
    return publicUrl;
  }
};

export const flashcardsApi = {
  async getFlashcards(userId: string): Promise<Flashcard[]> {
    const { data, error } = await supabase
      .from('flashcards')
      .select('*')
      .eq('user_id', userId)
      .order('next_review_date', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getDueFlashcards(userId: string): Promise<Flashcard[]> {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('flashcards')
      .select('*')
      .eq('user_id', userId)
      .lte('next_review_date', today)
      .order('next_review_date', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createFlashcard(flashcard: Omit<Flashcard, 'id' | 'created_at'>): Promise<Flashcard | null> {
    const { data, error } = await supabase
      .from('flashcards')
      .insert(flashcard)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateFlashcard(id: string, updates: Partial<Flashcard>): Promise<Flashcard | null> {
    const { data, error } = await supabase
      .from('flashcards')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async deleteFlashcard(id: string): Promise<void> {
    const { error } = await supabase
      .from('flashcards')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};

export const quizzesApi = {
  async getQuizzes(userId: string): Promise<Quiz[]> {
    const { data, error } = await supabase
      .from('quizzes')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createQuiz(quiz: Omit<Quiz, 'id' | 'created_at'>): Promise<Quiz | null> {
    const { data, error } = await supabase
      .from('quizzes')
      .insert(quiz)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getQuizAttempts(userId: string, quizId?: string): Promise<QuizAttempt[]> {
    let query = supabase
      .from('quiz_attempts')
      .select('*')
      .eq('user_id', userId);
    
    if (quizId) {
      query = query.eq('quiz_id', quizId);
    }
    
    const { data, error } = await query.order('completed_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createQuizAttempt(attempt: Omit<QuizAttempt, 'id' | 'completed_at'>): Promise<QuizAttempt | null> {
    const { data, error } = await supabase
      .from('quiz_attempts')
      .insert(attempt)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  }
};

export const studyPlansApi = {
  async getStudyPlans(userId: string): Promise<StudyPlan[]> {
    const { data, error } = await supabase
      .from('study_plans')
      .select('*')
      .eq('user_id', userId)
      .order('start_date', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createStudyPlan(plan: Omit<StudyPlan, 'id' | 'created_at'>): Promise<StudyPlan | null> {
    const { data, error } = await supabase
      .from('study_plans')
      .insert(plan)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateStudyPlan(id: string, updates: Partial<StudyPlan>): Promise<StudyPlan | null> {
    const { data, error } = await supabase
      .from('study_plans')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async deleteStudyPlan(id: string): Promise<void> {
    const { error } = await supabase
      .from('study_plans')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};

export const achievementsApi = {
  async getAchievements(userId: string): Promise<Achievement[]> {
    const { data, error } = await supabase
      .from('achievements')
      .select('*')
      .eq('user_id', userId)
      .order('unlocked_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async createAchievement(achievement: Omit<Achievement, 'id' | 'unlocked_at'>): Promise<Achievement | null> {
    const { data, error } = await supabase
      .from('achievements')
      .insert(achievement)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  }
};

export const notificationsApi = {
  async getNotifications(userId: string): Promise<Notification[]> {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async markAsRead(id: string): Promise<void> {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', id);
    
    if (error) throw error;
  },

  async createNotification(notification: Omit<Notification, 'id' | 'created_at'>): Promise<Notification | null> {
    const { data, error } = await supabase
      .from('notifications')
      .insert(notification)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  }
};
