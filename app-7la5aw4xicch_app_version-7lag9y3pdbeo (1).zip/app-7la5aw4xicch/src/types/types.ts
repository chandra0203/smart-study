export type UserRole = 'user' | 'admin';
export type DifficultyLevel = 'easy' | 'medium' | 'hard';
export type ImportanceLevel = 'low' | 'medium' | 'high';
export type NotificationType = 'reminder' | 'achievement' | 'tip';

export interface Profile {
  id: string;
  email: string | null;
  username: string | null;
  avatar_url: string | null;
  role: UserRole;
  xp_points: number;
  level: number;
  streak_days: number;
  last_study_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface Subject {
  id: string;
  user_id: string;
  name: string;
  color: string;
  icon: string | null;
  created_at: string;
}

export interface StudySession {
  id: string;
  user_id: string;
  subject_id: string | null;
  topic: string;
  duration_minutes: number;
  difficulty: DifficultyLevel;
  importance: ImportanceLevel;
  notes: string | null;
  date: string;
  created_at: string;
}

export interface Document {
  id: string;
  user_id: string;
  subject_id: string | null;
  title: string;
  file_url: string;
  file_type: string;
  processed: boolean;
  extracted_text: string | null;
  topics: Record<string, unknown> | null;
  created_at: string;
}

export interface Flashcard {
  id: string;
  user_id: string;
  subject_id: string | null;
  document_id: string | null;
  question: string;
  answer: string;
  difficulty: DifficultyLevel;
  next_review_date: string;
  review_count: number;
  confidence_level: number;
  created_at: string;
}

export interface Quiz {
  id: string;
  user_id: string;
  subject_id: string | null;
  document_id: string | null;
  title: string;
  questions: QuizQuestion[];
  total_questions: number;
  difficulty: DifficultyLevel;
  created_at: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correct_answer: number;
  explanation?: string;
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  quiz_id: string;
  score: number;
  total_questions: number;
  answers: Record<string, unknown>;
  time_taken_seconds: number;
  completed_at: string;
}

export interface StudyPlan {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  start_date: string;
  end_date: string;
  tasks: StudyTask[];
  created_at: string;
}

export interface StudyTask {
  id: string;
  title: string;
  subject_id?: string;
  duration_minutes: number;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  scheduled_date?: string;
}

export interface Achievement {
  id: string;
  user_id: string;
  achievement_type: string;
  title: string;
  description: string;
  icon: string;
  xp_reward: number;
  unlocked_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  read: boolean;
  created_at: string;
}

export interface StudySessionWithSubject extends StudySession {
  subject?: Subject;
}

export interface AnalyticsData {
  totalHours: number;
  totalSessions: number;
  averageSessionLength: number;
  productivityScore: number;
  mostProductiveTime: string;
  focusScore: number;
  subjectBreakdown: {
    subject: string;
    hours: number;
    color: string;
  }[];
  weeklyProgress: {
    date: string;
    hours: number;
  }[];
  weakestSubjects: {
    subject: string;
    hours: number;
  }[];
}

export interface AIAnalysisRequest {
  subject: string;
  topics: string[];
  documentId?: string;
  analysisType: 'mcqs' | 'important_topics' | 'summary' | 'revision' | 'weakness_check' | 'exam_practice';
}

export interface AIAnalysisResponse {
  success: boolean;
  data: {
    topics?: string[];
    importantPoints?: string[];
    mcqs?: QuizQuestion[];
    summary?: string;
    revisionNotes?: string[];
    weaknesses?: string[];
    examQuestions?: QuizQuestion[];
    confidenceScores?: Record<string, number>;
  };
}
